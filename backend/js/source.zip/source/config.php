<?php
/*Database Settings*/

$db_host ="localhost" ;
$db_name = "xycoords";
$db_usr = "root";
$db_pass = "dustin321a";

$link = mysqli_connect($db_host, $db_usr, $db_pass) or die("MySQL Error: " . mysqli_error());
mysqli_select_db($link, $db_name) or die("MySQL Error: " . mysqli_error());
?>
