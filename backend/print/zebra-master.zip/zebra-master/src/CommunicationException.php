<?php

namespace Zebra;

use RuntimeException;

class CommunicationException extends RuntimeException
{
    //
}
